# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.types import *

# COMMAND ----------

container_origen = 'neptuno'
container_destino = 'marcelo-sica'
datalake = 'dlformacion'
tablas = []

# COMMAND ----------

access_key = 'FIPeodgc8WLFK0TvcI+UHily5K2uvBp5AeryqRvqsc6fEapQj8vfEOhZs5R8xl9YX0MhvIaXK8L5+AStPinFvw=='
spark.conf.set(f'fs.azure.account.key.{datalake}.dfs.core.windows.net', access_key)

# COMMAND ----------

dbutils.fs.ls(f'abfss://{container_origen}@{datalake}.dfs.core.windows.net/CSV')

# COMMAND ----------

for tabla in dbutils.fs.ls(f'abfss://{container_origen}@{datalake}.dfs.core.windows.net/CSV'):
    if tabla[1] == 'neptuno_presupuesto_fact.csv':
        separador = '|'
    elif tabla[1] in ['neptuno_fecha_dim.csv']:
        separador = ','
    else:
        separador = ';'
    exec(f'df_{tabla[1].replace(".csv", "").replace(" ", "_")} = spark.read.load("{tabla[0]}", format="csv" , sep= "{separador}" , header="true", inferSchema = True)')


# COMMAND ----------

df_neptuno_presupuesto_fact.display()

# COMMAND ----------

df_neptuno_presupuesto_fact.printSchema()

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, DoubleType, StringType

schema = StructType([
    StructField("id_presupuesto", IntegerType(), True),
    StructField("id_categoria", IntegerType(), True),
    StructField("id_fecha", IntegerType(), True),
    StructField("id_direccion", IntegerType(), True),
    StructField("monto", DoubleType(), True)
])


df_neptuno_presupuesto_fact = spark.read.load(tabla[0], format="csv", sep=separador, header="true", schema=schema)

# COMMAND ----------

# MAGIC %md 
# MAGIC DF_CATEGORIAS LIMPIEZA

# COMMAND ----------

df_Categorías = df_Categorías.withColumnRenamed('Imagen','Descripcion')
df_Categorías = df_Categorías.withColumn("Nombre de categoria", F.col(df_Categorías.columns[1]))

# COMMAND ----------

df_Categorías = df_Categorías.drop( df_Categorías.columns[1])

# COMMAND ----------

df_Categorías.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Se elimina la columna "Descripcion" (sin tilde) por contener todos sus valores nulos

# COMMAND ----------

df_Categorías = df_Categorías.drop("Descripcion")

# COMMAND ----------

df_Categorías.printSchema()

# COMMAND ----------

df_Categorías.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC Union de pedidos, clientes y proovedores

# COMMAND ----------

df_Clientes.limit(5).display()

# COMMAND ----------

df_Pedidos.limit(5).display()

# COMMAND ----------

df_Proveedores.limit(20).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Se renombran las columnas

# COMMAND ----------

tabla1 = df_Pedidos.select('Ciudad de destinatario','País de destinatario')

# COMMAND ----------

tabla2 = df_Proveedores.select('Ciudad','País')

# COMMAND ----------

tabla3= df_Clientes.select('Ciudad','País')

# COMMAND ----------

df = tabla1.union(tabla2).union(tabla3)
df.limit(50).display()

# COMMAND ----------

df = df.withColumnRenamed("Ciudad de destinatario", "Ciudad").withColumnRenamed("País de destinatario", "País")

# COMMAND ----------

# MAGIC %md
# MAGIC Se eliminan duplicados

# COMMAND ----------

df = df.drop_duplicates().orderBy('País', ascending = True)
df.display()

# COMMAND ----------

ciudad = ['Brandenburgo','Francfurt', 'Frankfurt a.M.','Salzburg', 'Rio de Janeiro','Bruxelles', 'Montréal',  'Marseille', 'London','Sao Paulo'] 

# COMMAND ----------

df_eliminar_repetidos = df.where(F.col('ciudad').isin(ciudad))

# COMMAND ----------

df = df.subtract(df_eliminar_repetidos).orderBy('País', ascending = True)

# COMMAND ----------

df.limit(100).display()

# COMMAND ----------

eliminar = df.filter(F.col('ciudad').rlike('Frankfurt a.M')).orderBy('País','Ciudad', ascending = True)

# COMMAND ----------

df = df.subtract(eliminar).orderBy('País', ascending = True) 

# COMMAND ----------

df.limit(50).display()

# COMMAND ----------

df_incremental = df.withColumn("id", monotonically_increasing_id() + 1)

# COMMAND ----------

# MAGIC %md
# MAGIC Se ordenan las columnas, dejando ID como primer columna

# COMMAND ----------

df_direcciones = df_incremental.select('id','Ciudad','País')
df_direcciones.limit(50).display()


# COMMAND ----------

df_direcciones.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC ##df_Clientes

# COMMAND ----------

# MAGIC %md
# MAGIC le agregamos id

# COMMAND ----------

df_Clientes = df_Clientes.withColumn("id_cliente", monotonically_increasing_id() + 1)

# COMMAND ----------

df_Clientes.limit(5).display()

# COMMAND ----------

df_Clientes.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Se quiere contar cuantos son no nulos de la columna "Prop_6" y como la mayoria son nulos se procede a borrarla
# MAGIC

# COMMAND ----------

cantidad_de_no_nulos = df_Clientes.filter(F.col("Región").isNotNull()).count()
print(cantidad_de_no_nulos)

# COMMAND ----------

df_Clientes = df_Clientes.drop("Región")

# COMMAND ----------

df_Clientes.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC ##df_companias_de_envios

# COMMAND ----------

df_Compañías_de_envíos.limit(10).display()

# COMMAND ----------

df_Compañías_de_envíos.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Elimino teléfono no me sirve para analisis

# COMMAND ----------

df_Compañías_de_envíos = df_Compañías_de_envíos.drop('Teléfono')

# COMMAND ----------

df_Compañías_de_envíos.display()

# COMMAND ----------

df_Compañías_de_envíos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC ##df_Detalles_de_pedidos

# COMMAND ----------

df_Detalles_de_pedidos.limit(10).display()

# COMMAND ----------

df_Detalles_de_pedidos.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Se comprueba que claramente la columna "F6" esta llena de 0 , por eso se decide eliminarla, ya que al contar cuantos son distintos de 0 el valor fue ninguno

# COMMAND ----------

cantidad_de_celdas_sin_0 = df_Detalles_de_pedidos.filter(F.col("F6") != "0").count()
print(cantidad_de_celdas_sin_0)

# COMMAND ----------

df_Detalles_de_pedidos = df_Detalles_de_pedidos.drop("F6")

# COMMAND ----------

# MAGIC %md
# MAGIC Utilizando expreciones regulares a la columna "Precio por unidad" le saque el signo $ y el espacio para poder luego castearlas y hacerlas funcional

# COMMAND ----------

df_Detalles_de_pedidos = df_Detalles_de_pedidos.withColumn("Precio por unidad", F.regexp_replace(F.col("Precio por unidad"), r'[$ ]', ''))

# COMMAND ----------

df_Detalles_de_pedidos = df_Detalles_de_pedidos.withColumn("Precio por unidad", F.regexp_replace(F.col("Precio por unidad"), ",", "."))
df_Detalles_de_pedidos = df_Detalles_de_pedidos.withColumn("Descuento", F.regexp_replace(F.col("Descuento"), ",", "."))


# COMMAND ----------

df_Detalles_de_pedidos.limit(20).display()

# COMMAND ----------

df_Detalles_de_pedidos = df_Detalles_de_pedidos.withColumn("Precio por unidad", F.col("Precio por unidad").cast("double")) \
        .withColumn("Descuento", F.col("Descuento").cast("float"))

# COMMAND ----------

df_Detalles_de_pedidos = df_Detalles_de_pedidos.withColumnRenamed("Id. de pedido", "id_pedido")

# COMMAND ----------

df_Detalles_de_pedidos.limit(5).display()

# COMMAND ----------

df_Detalles_de_pedidos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC ##df_Empleados

# COMMAND ----------

df_Empleados.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Se borro la columna Foto porque al analisis no aporta ningun tipo de informacion necesaria para el analisis, lo mismo con Notas y Siglas

# COMMAND ----------

df_Empleados = df_Empleados.drop("Foto")
df_Empleados = df_Empleados.drop("Notas")
df_Empleados = df_Empleados.drop("Siglas")

# COMMAND ----------

# MAGIC %md
# MAGIC En las columnas Fecha de nacimiento y Fecha de contratacion se realizo un split para eliminar todo el resto del contenido (hora)

# COMMAND ----------

df_Empleados = df_Empleados.withColumn("Fecha de nacimiento", F.split(F.col("Fecha de nacimiento"), " ")[0]) \
      .withColumn("Fecha de contratación", F.split(F.col("Fecha de contratación"), " ")[0])

# COMMAND ----------

# MAGIC %md
# MAGIC Basándose en la descripcion de Jefe se toma como referencia que todo lo que tenga la palabra ascendido o ascendida es porque es jefe, por ende, el dato True o False parece mucho mas descriptivo

# COMMAND ----------

df_Empleados.limit(20).display()

# COMMAND ----------

df_Empleados = df_Empleados.withColumnRenamed("Jefe","Jefe_")

# COMMAND ----------

df_Empleados = df_Empleados.withColumn("Jefe", F.when((F.col("Jefe_").like("%ascendido%")) | (F.col("Jefe_").like("%ascendida%")), True).otherwise(False))

# COMMAND ----------

df_Empleados = df_Empleados.drop("Jefe_")

# COMMAND ----------

df_Empleados.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Tambien se procede a borrar la columna Codigo postal ya que sus datos no poseen ninguna coherencia

# COMMAND ----------

df_Empleados = df_Empleados.drop("Código postal")

# COMMAND ----------

df_Empleados = df_Empleados.withColumnRenamed("País","Código postal").withColumnRenamed("Teléfono de domicilio","País")

# COMMAND ----------

df_Empleados.display()

# COMMAND ----------

df_Empleados = df_Empleados.withColumnRenamed("Extensión","Temp")

# COMMAND ----------

df_Empleados = df_Empleados.withColumn("temp", F.regexp_replace(F.col("Temp"), "[()]", ""))
df_Empleados = df_Empleados.withColumn("Extensión", F.split(F.col("Temp"), " ")[0])
df_Empleados = df_Empleados.withColumn("Teléfono", F.split(F.col("Temp"), " ")[1])

# COMMAND ----------

df_Empleados.display()

# COMMAND ----------

df_Empleados = df_Empleados.drop("Temp")

# COMMAND ----------

df_Empleados.display()

# COMMAND ----------

df_Empleados = df_Empleados.withColumnRenamed('Código postal','País')

# COMMAND ----------

df_Empleados = df_Empleados.drop('País')

# COMMAND ----------

df_Empleados = df_Empleados.drop('Cargo')

# COMMAND ----------

df_Empleados = df_Empleados.drop('Tratamiento')

# COMMAND ----------

# MAGIC %md
# MAGIC Se elimina la columna "Teléfono" ya que todos sus valores son nulos

# COMMAND ----------

df_Empleados = df_Empleados.drop("Teléfono")

# COMMAND ----------

df_Empleados.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC ##df_Pedidos

# COMMAND ----------

df_Pedidos.limit(50).display()

# COMMAND ----------

df_Pedidos.printSchema()

# COMMAND ----------

cantidad_de_no_nulos1 = df_Pedidos.filter(F.col('Región de destinatario').isNotNull()).count()
print(cantidad_de_no_nulos)

# COMMAND ----------

# MAGIC %md
# MAGIC Se borra region de destinario ya que esta lleno de nulos

# COMMAND ----------


df_Pedidos = df_Pedidos.drop("Región de destinatario")

# COMMAND ----------

# MAGIC %md
# MAGIC Se revisa si hay ciudades repetidas o mal escritos

# COMMAND ----------

df_Pedidos.select('Ciudad de destinatario').distinct().display()

# COMMAND ----------

df_Pedidos = df_Pedidos.drop_duplicates()
df_Pedidos.limit(100).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Se modifica la columna "Id. de pedido" a "id_pedido" para poder hacer el JOIN con la df_Detalles_de_pedidos mas adelante

# COMMAND ----------

df_Pedidos = df_Pedidos.withColumnRenamed("Id. de pedido", "id_pedido")

# COMMAND ----------

df_Pedidos.limit(10).display()

# COMMAND ----------

ciudad = ['Brandenburgo','Francfurt', 'Frankfurt a.M.','Salzburg', 'Rio de Janeiro','Bruxelles', 'Montréal',  'Marseille', 'London','Sao Paulo','Versaille']

# COMMAND ----------

df_Pedidos.limit(100).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Hay que renombrar las ciudades que esta en esa lista

# COMMAND ----------

ciudad = ['Brandenburgo','Francfurt', 'Frankfurt a.M.','Salzburg', 'Rio de Janeiro','Bruxelles', 'Montréal',  'Marseille', 'London','Sao Paulo'] #nombres que tienen que ir frankfut salzburg São Paulo Río de Janeiro Bruselas Montreal Marsella londres

# COMMAND ----------

def cambiar_ciudades (df,columna,buscar,reemplazar):
        return df.withColumn(columna, F.when(df[columna] == buscar, reemplazar).otherwise(df[columna]))

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Salzburg','Salzburgo')

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Francfurt','Frankfurt')

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Bruxelles','Bruselas')

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Rio de Janeiro','Río de Janeiro')

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Brandenburg','Brandenburgo')

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Montréal','Montreal')

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Marseille','Marsella')

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','London','Londres') 

# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Sao Paulo','São Paulo') 


# COMMAND ----------

df_Pedidos = cambiar_ciudades(df_Pedidos,'Ciudad de destinatario','Frankfurt a.M. ','Frankfurt')

# COMMAND ----------

df_Pedidos.select('Ciudad de destinatario').distinct().display()

# COMMAND ----------

df_Pedidos.select('Ciudad de destinatario','País de destinatario').orderBy('País de destinatario', ascending = True).display()

# COMMAND ----------

columnas_fechas = ["Fecha de pedido","Fecha de entrega","Fecha de envío"]

# COMMAND ----------

for columna in columnas_fechas:
    df_Pedidos = df_Pedidos.withColumn(columna, F.split(F.col(columna), " ")[0])

# COMMAND ----------

df_Pedidos.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC eliminamos el nombre del destinatario no sirve para analisis

# COMMAND ----------

df_Pedidos = df_Pedidos.drop('Nombre de destinatario')

# COMMAND ----------

df_Pedidos.limit(5).display()

# COMMAND ----------

df_Pedidos = df_Pedidos.drop('Código postal de destinatario')

# COMMAND ----------

# MAGIC %md
# MAGIC Vemos cuantos valores no nulos tiene la columna region de destinatario

# COMMAND ----------

cantidad_de_no_nulos_pedidos = df_Pedidos.filter(F.col("Región de destinatario").isNotNull()).count()
print(cantidad_de_no_nulos)

# COMMAND ----------

# MAGIC %md
# MAGIC Al estar lleno de nulos eliminamos la columna

# COMMAND ----------

df_Pedidos = df_Pedidos.drop('Región de destinatario')

# COMMAND ----------

df_Pedidos.limit(50).display()

# COMMAND ----------

df_Pedidos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC df_Productos

# COMMAND ----------

df_Productos.limit(50).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Se verifica si hay filas duplicadas en df_Productos

# COMMAND ----------

num_filas_antes = df_Productos.count()
df_sin_duplicados = df_Productos.dropDuplicates()
num_filas_despues = df_sin_duplicados.count()

if num_filas_antes == num_filas_despues:
    print("No hay filas duplicadas en df_Productos.")
else:
    print(f"Hay {num_filas_antes - num_filas_despues} filas duplicadas en df_Productos.")


# COMMAND ----------

# MAGIC %md
# MAGIC Se elimina la columna "Suspendido" ya que no tiene relevancia alguna

# COMMAND ----------

df_Productos = df_Productos.drop("Suspendido")

# COMMAND ----------

# MAGIC %md
# MAGIC Se elimina las filas donde sus unidades en existencia, unidades pedidas y nivel de nuevo pedido coincidan en 0, es decir, que el producto no tiene unitilidad alguna para hacer un análisis de ventas

# COMMAND ----------

df_Productos = df_Productos.filter((df_Productos["Unidades en existencia"] != 0 ) | (df_Productos["Unidades pedidas"] != 0) | (df_Productos["Nivel de nuevo pedido"] != 0))

# COMMAND ----------

# MAGIC %md
# MAGIC En la columna "Cantidad por unidad", se decide renobrar algunas filas para que descriptivamente queden lo más parejas a las otras

# COMMAND ----------

df_Productos = df_Productos.withColumn('Cantidad por unidad', F.split(F.col('Cantidad por unidad'), " ")[0])

# COMMAND ----------

df_Productos = df_Productos.withColumn("Cantidad por unidad", F.col("Cantidad por unidad").cast("int"))

# COMMAND ----------

df_Productos = df_Productos.withColumn("Precio por unidad", F.regexp_replace(F.col("Precio por unidad"), r'[$ ]', ''))

# COMMAND ----------

df_Productos = df_Productos.withColumn("Precio por unidad", F.regexp_replace(F.col("Precio por unidad"), ",", "."))

# COMMAND ----------

df_Productos = df_Productos.withColumn("Precio por unidad", F.col("Precio por unidad").cast("double"))

# COMMAND ----------

df_Productos.limit(50).display()

# COMMAND ----------

df_Productos.printSchema()

# COMMAND ----------

df_Productos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC ##df_Proveedores

# COMMAND ----------

df_Proveedores.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Renombro ciudades  que estan mal escritas

# COMMAND ----------

df_Proveedores = cambiar_ciudades(df_Proveedores,'Ciudad','Montréal','Montreal')

# COMMAND ----------

df_Proveedores = cambiar_ciudades(df_Proveedores,'Ciudad','Sydney','Sídney')

# COMMAND ----------

df_Proveedores.select('Ciudad').display()

# COMMAND ----------

# MAGIC %md
# MAGIC Se verifica si hay filas duplicadas en df_Proveedores

# COMMAND ----------

num_filas_antes = df_Proveedores.count()
df_sin_duplicados = df_Proveedores.dropDuplicates()
num_filas_despues = df_sin_duplicados.count()

if num_filas_antes == num_filas_despues:
    print("No hay filas duplicadas en df_Productos.")
else:
    print(f"Hay {num_filas_antes - num_filas_despues} filas duplicadas en df_Productos.")


# COMMAND ----------

# MAGIC %md
# MAGIC Se elimina la columna "Página principal" ya que todos sus valores son nulos

# COMMAND ----------

df_Proveedores = df_Proveedores.drop("Página principal")

# COMMAND ----------

# MAGIC %md
# MAGIC Se elimina la columna "Región" ya que no se considera relevante

# COMMAND ----------

df_Proveedores = df_Proveedores.drop("Región")

# COMMAND ----------

# MAGIC %md
# MAGIC Se elimina la columna "Fax" ya que no se considera relevante

# COMMAND ----------

df_Proveedores = df_Proveedores.drop("Fax")

# COMMAND ----------

# MAGIC %md
# MAGIC Se elimina la columna "Telefóno" ya que no se considera relevante

# COMMAND ----------

df_Proveedores = df_Proveedores.drop("Teléfono")

# COMMAND ----------

df_Proveedores = df_Proveedores.drop("Código postal")

# COMMAND ----------

df_Proveedores = df_Proveedores.drop("Cargo del contacto")

# COMMAND ----------

df_Proveedores = df_Proveedores.drop("Nombre del contacto")

# COMMAND ----------

df_Proveedores.limit(50).display()

# COMMAND ----------

df_Proveedores.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC ##JOIN de df_Detalles_de_pedidos y df_Pedidos

# COMMAND ----------

df_Detalles_de_pedidos.printSchema()

# COMMAND ----------

df_Pedidos.printSchema()

# COMMAND ----------

df_Pedidos = df_Pedidos.withColumn("id_pedido", F.col("id_pedido").cast("integer"))

# COMMAND ----------

df_resultado_detalles_pedidos = df_Detalles_de_pedidos.join(df_Pedidos, "id_pedido", "inner")

# COMMAND ----------

df_resultado_detalles_pedidos.display()

# COMMAND ----------

# MAGIC %md
# MAGIC correcciones que faltaron y estan en el join

# COMMAND ----------

df_resultado_detalles_pedidos = df_resultado_detalles_pedidos.drop('Código postal de destinatario')

# COMMAND ----------

df_resultado_detalles_pedidos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC otros arreglos

# COMMAND ----------

df_Pedidos = df_Pedidos.withColumn("Cargo", F.regexp_replace(F.col("Cargo"), r'[$ ]', ''))

# COMMAND ----------

df_Pedidos = df_Pedidos.withColumn("Cargo", F.regexp_replace(F.col("Cargo"), ",", "."))

# COMMAND ----------

df_Pedidos.limit(30).display()

# COMMAND ----------

df_Pedidos = df_Pedidos.drop('Código postal de destinatario')

# COMMAND ----------

df_Pedidos = df_Pedidos.drop('Cargo')

# COMMAND ----------

# MAGIC %md
# MAGIC ##df_neptuno_fecha_dim

# COMMAND ----------

df_neptuno_fecha_dim.display()

# COMMAND ----------

# MAGIC %md 
# MAGIC Modificación columnas

# COMMAND ----------

df_neptuno_fecha_dim = df_neptuno_fecha_dim.withColumn("fecha_comp", F.regexp_replace(df_neptuno_fecha_dim["fecha_comp"], "-", "/"))

# COMMAND ----------

df_neptuno_fecha_dim = df_neptuno_fecha_dim.withColumn("fecha_comp", F.to_date(df_neptuno_fecha_dim["fecha_comp"], "yyyy/MM/dd"))
df_neptuno_fecha_dim = df_neptuno_fecha_dim.withColumn("fecha_comp", F.date_format(df_neptuno_fecha_dim["fecha_comp"], "dd/MM/yyyy"))

# COMMAND ----------

df_neptuno_fecha_dim.limit(10).display()

# COMMAND ----------

df_neptuno_fecha_dim = df_neptuno_fecha_dim.withColumn("id_fecha", df_neptuno_fecha_dim["fecha_comp"])

# COMMAND ----------

# MAGIC %md
# MAGIC Join entre pedidos y neptuno fecha

# COMMAND ----------

df_resultado = df_Pedidos.join(df_neptuno_fecha_dim, df_Pedidos["Fecha de Pedido"] == df_neptuno_fecha_dim["id_fecha"], how="inner")

# COMMAND ----------

df_resultado.limit(5).display()

# COMMAND ----------

df_resultado.printSchema()

# COMMAND ----------

df_resultado.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/neptuno/trusted-data/', format='parquet', mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC Neptuno Presupuesto

# COMMAND ----------

df_neptuno_presupuesto_fact.limit(100).display()

# COMMAND ----------

# MAGIC %md 
# MAGIC ESTRELLA 

# COMMAND ----------

df_Pedidos.limit(100).display()

# COMMAND ----------

# MAGIC %md 
# MAGIC Renombro columnas en neptuno para el join

# COMMAND ----------

df_neptuno_presupuesto_fact.limit(100).display()

# COMMAND ----------

df_Categorías = df_Categorías.withColumnRenamed('Id. de categoría','id_categoria')

# COMMAND ----------

df_Proveedores = df_Proveedores.withColumnRenamed('Id. de proveedor','id_proveedor')

# COMMAND ----------

df_Productos = df_Productos.withColumnRenamed('Id. de producto','id_producto')

# COMMAND ----------

df_Detalles_de_pedidos.limit(100).display()

# COMMAND ----------

df_neptuno_presupuesto_fact.limit(100).display()

# COMMAND ----------



tabla4 =  df_Clientes.select('id_cliente')

# COMMAND ----------

df_Compañías_de_envíos = df_Compañías_de_envíos.withColumnRenamed('Id. de compañía de envíos','id_compañias')

# COMMAND ----------

tabla5 = df_Compañías_de_envíos.select('id_compañias')

# COMMAND ----------

df_Empleados = df_Empleados.withColumnRenamed('Id. de empleado','id_empleado')

# COMMAND ----------

tabla6 = df_Empleados.select('id_empleado')

# COMMAND ----------

tabla7 = df_Pedidos.select('id_pedido')

# COMMAND ----------

tabla8 = df_Productos.select('id_producto')

# COMMAND ----------

tabla9 = df_Proveedores.select('id_proveedor')

# COMMAND ----------

df_direcciones = df_direcciones.withColumnRenamed('id','id_direccion')

# COMMAND ----------

tabla10 = df_direcciones.select('id_direccion')

# COMMAND ----------

tabla11 = df_neptuno_fecha_dim.select('id_fecha')

# COMMAND ----------

df_Detalles_de_pedidos.limit(5).display()

# COMMAND ----------

df_Detalles_de_pedidos = df_Detalles_de_pedidos.drop('Descuento')

# COMMAND ----------

df_Detalles_de_pedidos = df_Detalles_de_pedidos.withColumnRenamed('id_pedido','id_detalle')

# COMMAND ----------

tabla12 = df_Detalles_de_pedidos.select('id_detalle')

# COMMAND ----------

tabla13 = df_neptuno_presupuesto_fact.select('id_presupuesto')

# COMMAND ----------

# MAGIC %md
# MAGIC Creacion diagrama estrella th 

# COMMAND ----------

# DBTITLE 1,e
df_Categorías

# COMMAND ----------

th_estrella = df_Detalles_de_pedidos

# COMMAND ----------



# COMMAND ----------

df_Pedidos

# COMMAND ----------

df_resultado.limit(10).display()

# COMMAND ----------

df_Pedidos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/pedidos', format='parquet', mode='overwrite') 
df_Proveedores.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/proveedores', format='parquet', mode='overwrite') 
df_Categorías.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/categorias', format='parquet', mode='overwrite') 
df_Clientes.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/clientes', format='parquet', mode='overwrite')
df_Compañías_de_envíos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/compañia-envios', format='parquet', mode='overwrite') 
df_Detalles_de_pedidos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/detalle-pedidos', format='parquet', mode='overwrite') 
df_Empleados.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/empleados', format='parquet', mode='overwrite') 
df_Productos.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/productos', format='parquet', mode='overwrite') 
df_direcciones.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/direcciones', format='parquet', mode='overwrite') 
df_neptuno_fecha_dim.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/neptuno_fecha_dim', format='parquet', mode='overwrite') 
df_neptuno_presupuesto_fact.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/neptuno_presupuesto_fact', format='parquet', mode='overwrite') 
df_resultado.write.save(f'abfss://{container_destino}@{datalake}.dfs.core.windows.net/{path_trusted_data}/neptuno_presupuesto_fact', format='parquet', mode='overwrite') 


# COMMAND ----------

jdbcServer = 'agustin-marina'
jdbcHostname = jdbcServer + ".database.windows.net"
jdbcPort = 1433
jdbcDatabase = "neptuno_refined"
jdbcUsername = "administrador"
jdbcPassword = "Formacion1"
jdbcDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
 
connectionProperties = {
  "user" : jdbcUsername,
  "password" : jdbcPassword,
  "driver" : jdbcDriver
}

jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3}@{4};password={5};encrypt=true;trustServerCertificate=false;hostNameInCertificate=.database.windows.net;loginTimeout=30;".format(jdbcHostname, jdbcPort, jdbcDatabase, jdbcUsername, jdbcServer, jdbcPassword)

# COMMAND ----------

#df_Categorías.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','Categorias_Grupo_3').save()
#df_Clientes.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','Clientes_Grupo_3').save()
#df_Compañías_de_envíos.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','Compañias_de_envios_Grupo_3').save()
#df_Detalles_de_pedidos.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','df__Detalles_de_pedidos_Grupo_3').save()
#df_Empleados.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','df__Empleados_Grupo_3').save()
#df_Pedidos.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable',' df_Pedidos_Grupo_3').save()
#df_Productos.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','df__Productos_Grupo_3').save()
#df_Proveedores.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','df__Proveedores_Grupo_3').save()
#df.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','df_ciudades_Grupo_3').save()
#df_neptuno_fecha_dim.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','df_fecha_dim_Grupo_3').save()
#df_neptuno_presupuesto_fact.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','df_presupuesto_fact_Grupo_3').save()
#df_resultado.write.mode('overwrite').format('jdbc').option('driver',jdbcDriver).option('url',jdbcUrl).option('dbtable','df_resultado_Grupo_3').save()