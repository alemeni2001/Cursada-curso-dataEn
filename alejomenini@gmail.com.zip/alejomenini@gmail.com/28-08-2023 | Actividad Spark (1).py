# Databricks notebook source
# MAGIC %md
# MAGIC # Ejercicio 1
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### El cliente tiene un dataset de propiedades. Nos pide que le realicemos algunas transformaciones y lo subamos a una base de datos SQL. También espera que respondamos algunas preguntas sobre los datos.
# MAGIC ```
# MAGIC datalake: dlformacion
# MAGIC contenedor: propiedades
# MAGIC dataset: prop3.csv
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ##Imports

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql import functions
from pyspark.sql import DataFrame
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.functions import col, when

# COMMAND ----------

# MAGIC %md
# MAGIC ##Conexion datalake

# COMMAND ----------

datalake = 'dlformacion'
contenedor_origen = 'propiedades'
dataset = 'prop3'

# COMMAND ----------

spark = SparkSession.builder.appName('DataFrame').getOrCreate()

# COMMAND ----------

access_key = dbutils.secrets.get(scope='conexion-datalake', key='access-key')
spark.conf.set(f'fs.azure.account.key.{datalake}.dfs.core.windows.net', access_key)

# COMMAND ----------

exec(f"df_{dataset} = spark.read.load('abfss://{contenedor_origen}@{datalake}.dfs.core.windows.net/{dataset}.csv', format='csv', sep=',', header='true', inferSchema=True)")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformaciones
# MAGIC

# COMMAND ----------

df_prop3.limit(5).display()

# COMMAND ----------

df_prop3.columns

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformacion adicional

# COMMAND ----------

# MAGIC %md
# MAGIC Como transformacion adicional decidi realizar el del id ya que su importancia es vital para el analisis decidi darle un valor incremental y no el string que estaba antes.

# COMMAND ----------

df_prop3_transformado = df_prop3.withColumn("id",monotonically_increasing_id()+1)

# COMMAND ----------

df_prop3_transformado.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##long y latitud out of range

# COMMAND ----------

lat_min = -35
lat_max = -34
lon_min = -59
lon_max = -58

# COMMAND ----------

df_prop3_transformado = df_prop3_transformado.filter((col("lat") >= lat_min) & (col("lat") <= lat_max) & (col("lon") >= lon_min) & (col("lon") <= lon_max))

# COMMAND ----------

df_prop3_transformado.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Conversion

# COMMAND ----------

df_selected_currency = df_prop3_transformado.select(col("currency")).distinct()

# COMMAND ----------

df_selected_currency.limit(5).display()

# COMMAND ----------

df_selected_price = df_prop3_transformado.select(F.col("price")).distinct()

# COMMAND ----------

df_selected_price.limit(5).display()

# COMMAND ----------

# Tasa de conversion del dolar
ars_to_usd = 730
uyu_to_usd = 37.71

# COMMAND ----------

df_prop3_transformado = df_prop3_transformado.withColumn(
    "price_usd",
    when(col("currency") == "ARS", col("price") / ars_to_usd)
    .when(col("currency") == "UYU", col("price") / uyu_to_usd)
    .otherwise(None)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Eliminamos nulos, ceros y negativos

# COMMAND ----------

df_prop3_transformado = df_prop3_transformado.filter(
    (col("price").isNotNull()) &
    (col("price") > 0) &
    (col("surface_total").isNotNull()) &
    (col("surface_total") > 0)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Asignacion columna con tipo de datos
# MAGIC

# COMMAND ----------

df_prop3_transformado.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Segun mi criterio los datos que necesitan ser casteados es rooms, bedrooms y bathrooms ya que estos no tienen sentido que sean Doubles

# COMMAND ----------

df_prop3_transformado = df_prop3_transformado.withColumn("rooms", col("rooms").cast("integer")).withColumn("bedrooms", col("bedrooms").cast("integer")).withColumn("bathrooms", col("bathrooms").cast("integer"))

# COMMAND ----------

df_prop3_transformado.printSchema()

# COMMAND ----------

# DBTITLE 1,Transformaciones (Resolver con Pyspark)
# MAGIC %md
# MAGIC - Quitar todas las propiedades que se encuentren fuera del rango de las latitudes -35 a -34 y longitudes -59 a -58.
# MAGIC - Convertir a USD todos los precios de las propiedades que no estén expresados en USD de las siguientes cotizaciones: ARS y UYU. Para todas las otras monedas, se debe dejar el valor N/A.
# MAGIC https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.Column.when.html?highlight=when#pyspark.sql.Column.when                       
# MAGIC **ARS**: 730     
# MAGIC **UYU**: 37,71       
# MAGIC
# MAGIC
# MAGIC - Asignar a cada columna el tipo de dato que corresponda.
# MAGIC - Quitar los registros que contengan nulos, ceros o números negativos en las columnas: 'price' y 'surface_total'
# MAGIC - Elegir alguna transformación que te parezca apropiada y realizarla.

# COMMAND ----------

url = "jdbc:sqlserver://agustin-marina.database.windows.net;databaseName=propiedades"
properties = {
    "user": "administrador",
    "password": "Formacion1",
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}
df_prop3_transformado.write.jdbc(url=url, table="propiedades_AMenini", mode="overwrite", properties=properties)

# COMMAND ----------

# DBTITLE 1,Guardar el dataset en una base de datos
# MAGIC %md
# MAGIC ```
# MAGIC Servidor: agustin-marina.database.windows.net
# MAGIC Base de Datos: propiedades
# MAGIC Usuario: administrador
# MAGIC Contraseña: Formacion1
# MAGIC ```
# MAGIC
# MAGIC Guardar las tablas como "propiedades_{tuNombre}"

# COMMAND ----------

# DBTITLE 1,Preguntas (Resolver con Spark SQL)
# MAGIC %md
# MAGIC - ¿Cuántos registros tiene el dataset original?. ¿Y el dataset transformado?. Entonces, ¿Qué porcentaje del dataset original representa el dataset transformado?
# MAGIC - De las propiedades en alquiler, cuál es la más conveniente teniendo en cuenta la relación precio / superficie total?
# MAGIC - Un cliente busca comprar un PH en Villa Crespo que tenga más de 10m2 de superficie descubierta. ¿Cuántas opciones tiene disponibles para elegir?

# COMMAND ----------

# MAGIC %md
# MAGIC ##Creacion vistas temporales

# COMMAND ----------

df_prop3.createOrReplaceTempView('dataset_original')
df_prop3_transformado.createOrReplaceTempView('dataset_transformado')

# COMMAND ----------

# MAGIC %md
# MAGIC ##SQL

# COMMAND ----------

# MAGIC %md
# MAGIC - ¿Cuántos registros tiene el dataset original?. ¿Y el dataset transformado?. Entonces, ¿Qué porcentaje del dataset original representa el dataset transformado?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM dataset_original

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM dataset_transformado
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM dataset_original)),2) AS porcentaje_transformado
# MAGIC FROM dataset_transformado;

# COMMAND ----------

# MAGIC %md
# MAGIC - De las propiedades en alquiler, cuál es la más conveniente teniendo en cuenta la relación precio / superficie total?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     id,price, surface_total,
# MAGIC     ROUND(price / surface_total,3) AS relacion_precio_superficie
# MAGIC FROM dataset_transformado
# MAGIC ORDER BY relacion_precio_superficie ASC;

# COMMAND ----------

# MAGIC %md
# MAGIC - Un cliente busca comprar un PH en Villa Crespo que tenga más de 10m2 de superficie descubierta. ¿Cuántas opciones tiene disponibles para elegir?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS cantidad_opciones
# MAGIC FROM dataset_transformado
# MAGIC WHERE city = 'Villa Crespo'
# MAGIC     AND surface_total > 10;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Ejercicio 2

# COMMAND ----------

# DBTITLE 0,Conexión a la base de datos
# MAGIC %md
# MAGIC ```
# MAGIC Servidor: agustin-marina.database.windows.net
# MAGIC Base de Datos: AdventureWorks
# MAGIC Usuario: administrador
# MAGIC Contraseña: Formacion1
# MAGIC ```

# COMMAND ----------

jdbcServer = 'agustin-marina'
jdbcHostname = jdbcServer + ".database.windows.net"
jdbcPort = 1433
jdbcDatabase = "AdventureWorks"
jdbcUsername = "administrador"
jdbcPassword = "Formacion1"
jdbcDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
 
connectionProperties = {
  "user" : jdbcUsername,
  "password" : jdbcPassword,
  "driver" : jdbcDriver
}

jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3}@{4};password={5};encrypt=true;trustServerCertificate=false;hostNameInCertificate=.database.windows.net;loginTimeout=30;".format(jdbcHostname, jdbcPort, jdbcDatabase, jdbcUsername, jdbcServer, jdbcPassword)

# COMMAND ----------

adress_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.Address',properties=connectionProperties)
customer_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.Customer',properties=connectionProperties)
product_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.Product',properties=connectionProperties)
sales_order_header_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.SalesOrderHeader',properties=connectionProperties)
sales_cutomer_addres_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.CustomerAddress',properties=connectionProperties)
product_category_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.ProductCategory',properties=connectionProperties)
product_model_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.ProductModel',properties=connectionProperties)
sales_order_detail_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.SalesOrderDetail',properties=connectionProperties)
product_description_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.ProductDescription',properties=connectionProperties)
product_model_product_description_db = sqlContext.read.jdbc(url=jdbcUrl,table='SalesLT.ProductModelProductDescription',properties=connectionProperties)

# COMMAND ----------

# MAGIC %md
# MAGIC Realizar por lo menos 3 consultas SQL a elección y sacar algunas conclusiones del dataset.