# Databricks notebook source
# MAGIC %md
# MAGIC #Analisis con PySpark.
# MAGIC ##1) subir los csv en databricks con una notebook "origin-to-raw" en una carpeta que diga "shop-carrito" seguido de una carpeta 'raw-data', ejemplo {contenedor}/shop-carrito/raw-data/shop_carrito.csv
# MAGIC ##2) En un nuevo notebook "raw-to-trusted", realizar los joins correspondientes de las 7 tablas, la forma de unirlos es la siguiente:
# MAGIC • Shop-carrito -> shop-clientes por el campo “id_cliente”
# MAGIC
# MAGIC • Shop-carrito -> shop_campanias por el campo “id_campania”
# MAGIC
# MAGIC • Shop-carrito -> shop_articulos por el campo “id_articulo_ppal”
# MAGIC
# MAGIC • Shop-carrito -> shop_formapago por el campo “id_fpago”
# MAGIC
# MAGIC • Shop-carrito -> shop_carrito_estados por el campo “estado”
# MAGIC
# MAGIC • Shop-carrito -> shop_carrito_estados_pago por el campo “estado_pago”
# MAGIC
# MAGIC Al finalizar guardar el tablon en formato parquet en una carpeta que diga Trusted, ejemplo {contenedor}/trusted/tablon_shop_carrito
# MAGIC
# MAGIC ##3) una vez que tengas el tablon shop_carrito, realizar los analisis correspondientes:
# MAGIC
# MAGIC a) Quiero saber qué cantidad de solicitudes de compra se encuentran en cada estado, y el porcentaje en relación al total.
# MAGIC
# MAGIC b) Quiero conocer los clientes principales de la empresa, generando un ranking por cantidad y otro por monto, teniendo en cuenta solamente las compras finalizadas (efectuadas).
# MAGIC
# MAGIC c) Queremos ver cuáles fueron los medios de pago más utilizados por los clientes
# MAGIC
# MAGIC d) Realizar un analisis donde me determine las campanias mas eficaces.
# MAGIC
# MAGIC e) realizar 2 analisis mas y que nos expliques los resultados obtenidos.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Import

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
import re

# COMMAND ----------

# MAGIC %md
# MAGIC #Conexion con el datalake
# MAGIC

# COMMAND ----------

container_origen = 'alejo-menini'
datalake = 'dlformacion'

# COMMAND ----------

spark = SparkSession.builder.appName('DataFrame').getOrCreate()

# COMMAND ----------

access_key = dbutils.secrets.get(scope='conexion-datalake', key='access-key')
spark.conf.set(f'fs.azure.account.key.{datalake}.dfs.core.windows.net', access_key)

# COMMAND ----------

df_Shop_carrito_table = spark.read.parquet(f"abfss://{container_origen}@{datalake}.dfs.core.windows.net/shop-carrito/trusted-data/tablon-shop-carrito")

# COMMAND ----------

df_Shop_carrito_table.createOrReplaceTempView("shop_carrito")

# COMMAND ----------

# MAGIC %md
# MAGIC #Limpieza del dataset

# COMMAND ----------

# MAGIC %md
# MAGIC Como aclaracion las columnas que fueron dropeadas, lo ideal seria que al principio se le pregunte al cliente cuales piensa que no son importantes para el analisis. Como este es un ejercicio y esta especificado que tipo de datos y columnas vamos a utilizar como tambien en el ultimo punto especifica que segun mi criterio tengo que realizar dos analisis mas, entonces hay columnas que entorpecen a mi analisis por eso tome la desicion de borrarlas.
# MAGIC
# MAGIC Ademas por una cuestion de buenas practicas la limpieza del datatset, deberia hacerse en raw-to-trusted
# MAGIC

# COMMAND ----------

len(df_Shop_carrito_table.columns)

# COMMAND ----------

df_Shop_carrito_table.columns

# COMMAND ----------

COLUMNS_TO_DROP = ("entrecalles","direccion","numero","cp","localidad","estado_fecha","corte_generado_fecha","corte_generado","comentarios","comentarios_internos","ano","nota_credito","estado_logistico","id_oca","fecha_anulado","fecha_pago_pf","status_tango","fecha_aprobacion_bo","mail_fc_env","inbound","fecha_dia","fecha_mes","fecha_hora","fecha_ano","piso","dpto","tarjeta_titular","tarjeta_pagos","tarjeta_aprobacion","tarjeta_numero","tarjeta_codigo","tarjeta_vencimiento","t_entrega","status_tango","fecha_entrega","franja_horaria","sms_enviado","mail_ap_bo","export_hermes","hermes","export_bi","mail_ap_bo","indice_hermes","wp_notific","donacion","recompra_empresa","pae_final","pae_final","costo_logistica","telefono","telefono_alternativo","asiento_refacturacion","epack","id_campania_recalc","fecha_fin_tratamiento","nro_guia","id_pais_negocio","fecha")

df_Shop_carrito_table = df_Shop_carrito_table.drop(*COLUMNS_TO_DROP)

# COMMAND ----------

df_Shop_carrito_table.columns

# COMMAND ----------

df_Shop_carrito_table = df_Shop_carrito_table.dropDuplicates()

# COMMAND ----------

def dropColumnsWithNullPercentege(df, percentage):
    TOTAL_PERCENTAGE = 100/df.count()
    list_cantNull_columns = df.select([sum(isnull(column).cast("int")).alias(column) for column in df.columns]).collect()[0].asDict()
    for column in list_cantNull_columns:
        if((TOTAL_PERCENTAGE*list_cantNull_columns[column]) >= percentage):
            df = df.drop(column)
    return df


# COMMAND ----------

df_Shop_carrito_table = dropColumnsWithNullPercentege(df_Shop_carrito_table,70.0)

# COMMAND ----------

COLUMNS_FECHAS =  [column for column in df_Shop_carrito_table.columns if "fecha" in column]

# COMMAND ----------

for column in COLUMNS_FECHAS:
    df_Shop_carrito_table = df_Shop_carrito_table.withColumn(column,to_date(from_unixtime(col(column))))

# COMMAND ----------

df_Shop_carrito_table.select(COLUMNS_FECHAS).dtypes

# COMMAND ----------

df_Shop_carrito_table = df_Shop_carrito_table.withColumnRenamed("fecha_unix","fecha")

# COMMAND ----------

SPLIT_EMAIL = split(df_Shop_carrito_table.email,('@'))
df_Shop_carrito_table = df_Shop_carrito_table.withColumn("email",concat(SPLIT_EMAIL[0],lit("@"),lower(SPLIT_EMAIL[1])))

# COMMAND ----------

for column in ["courier","provincia"]:    
    df_Shop_carrito_table = df_Shop_carrito_table.withColumn(column,upper(trim(col(column))))

# COMMAND ----------

COLUMNS_TO_DROP = ["imagen1","opciones","pago_facil","sku","email_fc","parent_articulo","aviso_reposicion","tiempo_reposicion","costo_envio","URL","id_articulo_n","export_bi","regalia","id_cobranza","id_subnegocio","id_negocio","id_linea_producto","descripcion","id_gc","n_estable_gc","n_estable_pn","asiento_tango","recuperable","limitar_digitos","pago_diferido"]


df_Shop_carrito_table = df_Shop_carrito_table.drop(*COLUMNS_TO_DROP)


# COMMAND ----------

df_Shop_carrito_table = df_Shop_carrito_table.replace("NA", None)

# COMMAND ----------

for column in ["nombre","apellido"]:
    df_Shop_carrito_table = df_Shop_carrito_table.withColumn(column,initcap(col(column)))

# COMMAND ----------

# MAGIC %md
# MAGIC #Analisis
# MAGIC

# COMMAND ----------

df_Shop_carrito_table.columns

# COMMAND ----------

# MAGIC %md
# MAGIC ##EJERCICIO 1
# MAGIC Quiero saber qué cantidad de solicitudes de compra se encuentran en cada estado, y el porcentaje en relación al total.
# MAGIC

# COMMAND ----------

DF_ESTADO_PAGOS = df_Shop_carrito_table.groupBy("estado_pago").count().withColumnRenamed("estado_pago","estado_compras")

# COMMAND ----------

DF_ESTADO_PAGOS.withColumn('porcentaje',round(col("count") * 100 / df_Shop_carrito_table.count(),2)).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##EJERCICIO 2
# MAGIC Quiero conocer los clientes principales de la empresa, generando un ranking por cantidad y otro por monto, teniendo en cuenta solamente las compras finalizadas (efectuadas)

# COMMAND ----------

# MAGIC %md
# MAGIC Primero imprimo por pantalla las columnas de mi tabla de shop carrito para saber cual de estas voy a necesitar para mi analisis

# COMMAND ----------

df_Shop_carrito_table.columns

# COMMAND ----------

# MAGIC %md
# MAGIC Una vez seleccionada quiero saber el tipo de dato que se encuentra en mi tabla 

# COMMAND ----------

unique_= df_Shop_carrito_table.select("estado_fpag").distinct()
unique_.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Quiero filtrar a todos los clientes que tengan como estado pago ademas procedo a cambiar el valor de la columna a una mas descriptivo cambiando 0 por False, es decir no esta pago y 1 en True, si esta pago

# COMMAND ----------

FILTER_PAGO = df_Shop_carrito_table.withColumn("estado_fpag", when(col("estado_fpag") == 1, True).otherwise(False))

# COMMAND ----------

FILTER_PAGO.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Una vez ya filtrado y tenemos en una variable con los registros que estan en estado pago podemos proceder a realizar el ranking de clientes por monto o por cantidad

# COMMAND ----------

# Agrupar por cliente y contar la cantidad de transacciones
CANTIDAD_RANKING = FILTER_PAGO.groupBy("nombre").count()

# Ordenar en orden descendente
CANTIDAD_RANKING = CANTIDAD_RANKING.orderBy(col("count").desc())
CANTIDAD_RANKING = CANTIDAD_RANKING.withColumnRenamed("count", "cantidad_estado_pago")

# COMMAND ----------

CANTIDAD_RANKING.limit(5).display()

# COMMAND ----------

# Agrupar por cliente y sumar los montos de transacciones
MONTO_RANKING = FILTER_PAGO.groupBy("nombre").agg(sum("monto").alias("total_monto"))

# Ordenar en orden descendente
MONTO_RANKING = MONTO_RANKING.orderBy(col("total_monto").desc())

# COMMAND ----------

MONTO_RANKING.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##EJERCICIO 3
# MAGIC Queremos ver cuáles fueron los medios de pago más utilizados por los clientes
# MAGIC

# COMMAND ----------

df_Shop_carrito_table.columns

# COMMAND ----------

# MAGIC %md
# MAGIC Seleccione en este caso dos columnas metodo y forma pago si bien forma pago cumpliria con la consigna el analisis de ambas me resulto mas adecuado
# MAGIC

# COMMAND ----------

METODO_PAGO_counts = FILTER_PAGO.groupBy("metodo").count()

# COMMAND ----------

METODO_PAGO_counts = METODO_PAGO_counts.orderBy(col("count").desc())
METODO_PAGO_counts = METODO_PAGO_counts.withColumnRenamed("count", "cantidad")

# COMMAND ----------

METODO_PAGO_counts.display()

# COMMAND ----------

FORMA_PAGO_counts=FILTER_PAGO.groupBy("formapago").count()

# COMMAND ----------

FORMA_PAGO_counts = FORMA_PAGO_counts.orderBy(col("count").desc())
FORMA_PAGO_counts = FORMA_PAGO_counts.withColumnRenamed("count", "cantidad")

# COMMAND ----------

FORMA_PAGO_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##EJERCICIO 4
# MAGIC Realizar un analisis donde me determine las campanias mas eficaces.

# COMMAND ----------

# MAGIC %md
# MAGIC Buenas alejo, fijate que la efectividad se refiere a la que mas "vende" o "mas ganancia genera".

# COMMAND ----------

# MAGIC %md
# MAGIC Se determino en este caso que las que serian las mas efectivas serian las que tardaron menos desde la fecha que se facturo hasta la fecha que se entrego

# COMMAND ----------

# Calcular la duración de cada campaña en días
CAMPANIA_DF = df_Shop_carrito_table.withColumn("duracion", datediff(col("fecha_facturado"), col("fecha_entregado")))

# Seleccionar el ID de la campaña y su duración
CAMPANIA_CON_DURACION = CAMPANIA_DF.select("id_campania", "duracion")

# Ordenar por duración en orden ascendente para encontrar las campañas más cortas
CAMPANIA_MAS_EFECTIVA = CAMPANIA_CON_DURACION.orderBy(col("duracion"))

# COMMAND ----------

# MAGIC %md
# MAGIC Como se puede observar habra algun problema con la carga de los datos o la seleccion de las columnas no es la correcta para identificar cual es la mas efectiva

# COMMAND ----------

MOST_EFFECTIVE_CAMPAIGN.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##EJERCICIO 5
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Si a futuro queremos deteminar algun target de que articulo suelen llevar mas segun el sexo de la persona, seria bueno determinar la cantidad de personas que compran de que genero son

# COMMAND ----------

ARTICULOS_POR_GENERO = df_Shop_carrito_table.groupBy("sexo", "articulo").agg(sum("cantidad").alias("cantidad_articulos"))

ARTICULOS_POR_GENERO = ARTICULOS_POR_GENERO.orderBy(col("cantidad_articulos").desc())

ARTICULOS_POR_GENERO.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Si quiero hacer un analisis de tendencia segun mes y año del monto, para determinar algun tipo de patron y determinar que es lo que me esta generando un mayor indicie de promedio del monto 

# COMMAND ----------

DATA_DF = df_Shop_carrito_table.withColumn("anio", year("fecha")).withColumn("mes", month("fecha"))

PROMEDIO_MONTO_POR_MES_ANIO = DATA_DF.groupBy("anio", "mes").agg(round(avg("monto"), 2).alias("promedio_por_monto"))

PROMEDIO_MONTO_POR_MES_ANIO.display()