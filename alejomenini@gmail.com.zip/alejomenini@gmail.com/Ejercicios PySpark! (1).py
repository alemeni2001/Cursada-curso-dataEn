# Databricks notebook source
# MAGIC %md
# MAGIC # Importar librerias y cargar tablas

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import *

# COMMAND ----------

datalake = 'dlformacion'
contenedor_origen = 'star-wars'
tablas = ['characters', 'planets', 'starships', 'vehicles', 'species']

# COMMAND ----------

access_key = dbutils.secrets.get(scope='conexion-datalake', key='access-key')
spark.conf.set(f'fs.azure.account.key.{datalake}.dfs.core.windows.net', access_key)

# COMMAND ----------

for tabla in tablas:
    exec(f"df_{tabla} = spark.read.load('abfss://{contenedor_origen}@{datalake}.dfs.core.windows.net/{tabla}.csv', format='csv', sep=',', header='true', inferSchema=True)")

# COMMAND ----------

# MAGIC %md
# MAGIC # Ejercicios

# COMMAND ----------

# MAGIC %md
# MAGIC ### En "species" hay "mammal" y "mammals". Unificar los dos valores
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC .replace()

# COMMAND ----------

#Lucas
df_species = df_species.replace('mammals', 'mammal', subset=['classification'])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reemplazar los 'NA' (str) por null (None) en todas las tablas

# COMMAND ----------

# Juan Bertucci
for tabla in tablas:
    exec(f'df_{tabla} = df_{tabla}.replace("NA", None)')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cambiar el año de nacimiento (birth_year) de los personajes para que sean solo un número (y castearlos como corresponda)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC .withColumn()
# MAGIC .cast()
# MAGIC .split()

# COMMAND ----------

# Juan Manuel
df_characters = df_characters.withColumn('birth_year',F.split('birth_year','B')[0].cast('float'))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Teniendo en cuenta la tabla de personajes, hallar el promedio de altura según el planeta de origen
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC .groupby(homeword)
# MAGIC .agg()
# MAGIC

# COMMAND ----------

# Emiliano
df_characters = df_characters.withColumn("height", F.col("height").cast("float"))
avg_height = df_characters.groupBy("homeworld").agg(F.avg("height").alias("average_height"))
avg_height.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Averiguar el nombre del vehículo que necesita más tripulación

# COMMAND ----------

# MAGIC %md
# MAGIC .orderby()

# COMMAND ----------

# Tomás
vehiculo = df_vehicles.orderBy(F.col('crew').desc()).select('name')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Mostrar nombre de personaje, el planeta en el que nació (homeland), la población del planeta (population) y el peso del personaje en su planeta (masa * gravedad). Ordenados de mayor a menor población y solo si la población del planeta es MAYOR a 1000000

# COMMAND ----------

# MAGIC %md
# MAGIC - .join()
# MAGIC - .alias()
# MAGIC - .withColumn()
# MAGIC - .orderBy()
# MAGIC - .where()

# COMMAND ----------

#Juan Bertucci

# COMMAND ----------

df_characters = df_characters.withColumnRenamed('name', 'char_name')

# COMMAND ----------

df_union = df_characters.join(df_planets, F.col('homeworld') == df_planets.name, 'left')

# COMMAND ----------

df_union = df_union.withColumn('gravity', F.split(F.col('gravity'), ' ')[0])

# COMMAND ----------

df_union = df_union.replace('NA', None)

# COMMAND ----------

df_union = df_union.withColumn('weight', F.col('mass') * F.col('gravity'))

# COMMAND ----------

df_union = df_union.orderBy(F.col('population').cast(IntegerType()), ascending=False).filter(F.col('population').cast(IntegerType()) > 1000000)

# COMMAND ----------

df_union.select(F.col('char_name').alias('nombre_personaje'), 
                F.col('homeworld').alias('planeta_origen'), 
                F.col('population').alias('poblacion'),
                F.col('weight').alias('peso')).display()