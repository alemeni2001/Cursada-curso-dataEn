# Databricks notebook source
# MAGIC %md
# MAGIC # Import

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC # Variables

# COMMAND ----------

container_origen = 'agustin-marina'
container_destino = 'agustin-marina'
datalake = 'dlformacion'
tablas = ['articulos', 'campanias_gp', 'shop_carrito_estados_pago', 'shop_carrito_estados', 'Shop_carrito', 'Shop_clientes', 'shop_formapago']

# COMMAND ----------

# MAGIC %md
# MAGIC # SparkSession

# COMMAND ----------

spark = SparkSession.builder.appName('DataFrame').getOrCreate()

# COMMAND ----------

# MAGIC %md
# MAGIC # Conexión al Data Lake

# COMMAND ----------

access_key = 'FIPeodgc8WLFK0TvcI+UHily5K2uvBp5AeryqRvqsc6fEapQj8vfEOhZs5R8xl9YX0MhvIaXK8L5+AStPinFvw=='
spark.conf.set(f'fs.azure.account.key.{datalake}.dfs.core.windows.net', access_key)

# COMMAND ----------

# MAGIC %md
# MAGIC # Paths

# COMMAND ----------

for tabla in tablas:
    exec(f'PATH_{tabla} = "abfss://{container_origen}@{datalake}.dfs.core.windows.net/{tabla}.csv"')

# COMMAND ----------

# MAGIC %md
# MAGIC # DataFrames

# COMMAND ----------

for tabla in tablas:
    separador = ',' if (tabla in ['articulos', 'campanias_gp']) else ';'
    exec(f'df_{tabla.lower()} = spark.read.load(PATH_{tabla}, format = "csv", sep = "{separador}", header = "true", inferSchema = True)')

# COMMAND ----------

# MAGIC %md
# MAGIC # PySpark
# MAGIC [Documentación](https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/index.html)

# COMMAND ----------

DataFrame
Column
Row
GroupedData

# COMMAND ----------

# MAGIC %md
# MAGIC ## Carga de DataFrames
# MAGIC - spark.read.load() - ```spark.read.load(Str, format=Str, sep=Str, inferSchema=Bool/Str, header=Bool/Str)```

# COMMAND ----------

# DBTITLE 1,Spark.read.load( )
df_campanias_gp = spark.read.load(PATH_campanias_gp, format='csv', sep=',', header='true', inferSchema=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exploración
# MAGIC - display() - ```DataFrame.display() -> NoneType```
# MAGIC - show() - ```DataFrame.show(Int) -> NoneType```
# MAGIC - head() - ```DataFrame.head(Int) -> List```
# MAGIC - tail() - ```DataFrame.tail(Int) -> List```
# MAGIC --- 
# MAGIC - printSchema() - ```DataFrame.printSchema() -> NoneType```
# MAGIC - columns - ```DataFrame.columns -> List```
# MAGIC - dtype - ```DataFrame.dtype -> List```
# MAGIC - count() - ```DataFrame.count() -> Int```
# MAGIC ---
# MAGIC - orderBy() - ```DataFrame.orderBy(Col, ascending=Bool/List) -> DataFrame```
# MAGIC - select() - ```DataFrame.select(*Cols/*Str) -> DataFrame```
# MAGIC - distinct() - ```DataFrame.distinct() -> DataFrame```
# MAGIC - describe() - ```DataFrame.describe(*cols) -> DataFrame```

# COMMAND ----------

# MAGIC %md
# MAGIC ### display()/show()/head()/tail()

# COMMAND ----------

# DBTITLE 1,Display( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.display() -> NoneType```

# COMMAND ----------

type(df_campanias_gp.display())

# COMMAND ----------

# DBTITLE 1,Show( )
# MAGIC %md
# MAGIC ```DataFrame.show(Int) -> NoneType```

# COMMAND ----------

df_campanias_gp.show(5)

# COMMAND ----------

# DBTITLE 1,Head( )
# MAGIC %md
# MAGIC ```DataFrame.head(Int) -> List```

# COMMAND ----------

df_articulos.head(5)[0][0]

# COMMAND ----------

# DBTITLE 1,Tail( )
# MAGIC %md
# MAGIC ```DataFrame.tail(Int) -> List```

# COMMAND ----------

df_articulos.tail(1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### printSchema/columns/dtype/count()

# COMMAND ----------

# DBTITLE 1,PrintSchema( )
# MAGIC %md
# MAGIC ```DataFrame.printSchema() -> NoneType```

# COMMAND ----------

df_articulos.printSchema()

# COMMAND ----------

# DBTITLE 1,Columns
# MAGIC %md
# MAGIC ```DataFrame.columns -> List```

# COMMAND ----------

df_shop_carrito.columns

# COMMAND ----------

# DBTITLE 1,Dtypes
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.dtypes -> List
# MAGIC ```

# COMMAND ----------

df_articulos.dtypes

# COMMAND ----------

# DBTITLE 1,Count( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.count() -> Int```

# COMMAND ----------

df_shop_carrito_estados_pago.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### orderBy()/select()/distinct()/describe()

# COMMAND ----------

# DBTITLE 1,OrderBy( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.orderBy(Col/Str/List, ascending=Bool/List) -> DataFrame```

# COMMAND ----------

# df_articulos.orderBy('id', ascending=True).display()
# df_articulos.orderBy(df_articulos.id, ascending=False).display()
# df_articulos.orderBy(F.col('id').desc()).display()
df_articulos.orderBy(['id', 'id_marca'], ascending=[True, False]).display()

# COMMAND ----------

# DBTITLE 1,Select( ) / drop( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.select(*Cols/*Str) -> DataFrame```

# COMMAND ----------

df_articulos.drop('id', 'id_marca').display()

# COMMAND ----------

# DBTITLE 1,Distinct( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.distinct() -> DataFrame```

# COMMAND ----------

df_articulos.select('URL').distinct().display()

# COMMAND ----------

# DBTITLE 1,Describe( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.describe(*cols) -> DataFrame
# MAGIC ```

# COMMAND ----------

df_articulos.describe('id').display()

# COMMAND ----------

standar_dev = df_articulos.describe('id').head(5)[2][1]
standar_dev

# COMMAND ----------

# MAGIC %md
# MAGIC ## Columnas
# MAGIC - withColumn() -     ```DataFrame.withColumn(Str/Col, Col) -> DataFrame```
# MAGIC - withColumns() - ```DataFrame.withColumns(Dict{ Str : Col }) -> DataFrame```
# MAGIC - withColumnRenamed - ```DataFrame.withColumnRenamed(Str, Str) -> DataFrame```
# MAGIC ---
# MAGIC - round() - ```round(Col, Int) -> Col```
# MAGIC - concat() - ```concat(*Col) -> Col```
# MAGIC - lit() - ```lit(¿?) -> Col```
# MAGIC - cast() - ```Col.cast(Type/Str)```
# MAGIC - upper()/lower()/initcap() - ```upper(Str/Col) -> Col```
# MAGIC - split() - ```split(Str/Col, Str) -> Col```
# MAGIC - avg()/countDistinct()/alias() - ```alias(Str/Col) -> Col```

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,WithColumn( ) + round( ), concat( ), lit( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.withColumn(Str/Col, Col) -> DataFrame
# MAGIC ```

# COMMAND ----------

df_campanias_gp.display()

# COMMAND ----------

df_campanias_gp.dbsize/1000

# COMMAND ----------

df_campanias_gp = df_campanias_gp.withColumn('dbsize_gb', F.concat(F.round(df_campanias_gp.dbsize/1000, 2), F.lit(' GB')))

# COMMAND ----------

# DBTITLE 1,withColumns( ) + cast( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.withColumns(Dict{ Str : Col }) -> DataFrame```

# COMMAND ----------

df_shop_clientes.withColumns({'telefono_particular': df_shop_clientes.telefono_particular.cast('string'),
                               'telefono_laboral': df_shop_clientes.telefono_laboral.cast('string')})

# COMMAND ----------

# DBTITLE 1,WithColumn( ) + upper( ) / lower( ) / capitalize( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.withColumn(Str/Col, Col) -> DataFrame```

# COMMAND ----------

df_shop_clientes.withColumn('nombre', F.lower(df_shop_clientes.nombre))

# COMMAND ----------


# apellidos Capitalizados
df_shop_clientes.withColumn('apellido', F.initcap(F.col('apellido')))

# COMMAND ----------

# DBTITLE 1,WithColumnRenamed( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.withColumnRenamed(Str, Str) -> DataFrame```

# COMMAND ----------

# modifica el nombre de la columna email por correo electronico
df_shop_clientes.withColumnRenamed('email', 'correo_electronico')

# COMMAND ----------

# DBTITLE 1,WithColumn( ) + split( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.withColumn(Str/Col, Col) -> DataFrame```

# COMMAND ----------

df_campanias_gp.withColumn('dbsize_gb', F.split(F.col('dbsize_gb'), ' ')[0])

# COMMAND ----------

df_campanias_gp.withColumn('dbsize_gb', F.split(F.col('dbsize_gb'), ' ')[0])

# COMMAND ----------

# DBTITLE 1,Avg( ), countDistict( ), alias( )
# MAGIC %md
# MAGIC ```
# MAGIC avg()/countDistinct()/alias() - alias(Str/Col) -> Col```

# COMMAND ----------

df_articulos.select(F.avg(df_articulos.id).alias('id_promedio')).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filtrar
# MAGIC - filter()/where() - ```DataFrame.where(Col.BooleanType) -> DataFrame```
# MAGIC - groupBy() - ```DataFrame.groupBy(Col/Str/List) -> GroupedData```
# MAGIC - agg() - ```DataFrame.agg(Dict{Str(Col):Str(Fx)}/List) -> DataFrame``` [min, max, avg, sum]
# MAGIC ---

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Filter( ) / where( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.where(Col.BooleanType/Str) -> DataFrame```

# COMMAND ----------

type(df_articulos.costo.isNull())

# COMMAND ----------

# df_articulos.select('id', 'costo').where('costo > 10 AND id > 232').display()
df_articulos.where(df_articulos.descripcion == df_articulos.id).display()

# COMMAND ----------

# DBTITLE 1,GroupBy( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.groupBy(Col/Str/List) -> GroupedData```

# COMMAND ----------

df_articulos.printSchema()

# COMMAND ----------

df_articulos.groupBy('id_categoria').avg('cantidad').select('id_categoria', F.col('avg(cantidad)').alias('cantidad_promedio')).display()

# COMMAND ----------

# DBTITLE 1,Agg( ) - max, min, sum, avg
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.agg(Dict{Str(Col):Str(Fx)}/List) -> DataFrame```

# COMMAND ----------

df_articulos.agg({'id_courier': 'max',
                  'costo_envio': 'min'}).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Nulos
# MAGIC - isNull() / isNotNull() - ```Col.isNull() -> Col```
# MAGIC - dropna() - ```DataFrame.dropna(how=Str, thresh=Int, subset=Str/Tuple/List)```

# COMMAND ----------

# DBTITLE 1,IsNull( )
# MAGIC %md
# MAGIC ```
# MAGIC Col.isNull() -> Col.isNull() -> Col
# MAGIC ```

# COMMAND ----------

df_articulos.select('id',df_articulos.descripcion.isNotNull()).display()

# COMMAND ----------

# DBTITLE 1,Dropna( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.dropna(how=Str, thresh=Int, subset=Str/Tuple/List)
# MAGIC ```

# COMMAND ----------

df_articulos.dropna(how='any', subset='descripcion').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Limpieza
# MAGIC - replace() - ```DataFrame.replace(to_replace=¿?, value=¿?) -> DataFrame```
# MAGIC - dropDuplicates() - ```DataFrame.dropDuplicates(subset=List)```

# COMMAND ----------

# DBTITLE 1,Replace( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.replace(to_replace=¿?, value=¿?) -> DataFrame```

# COMMAND ----------

df_shop_clientes.replace('Cons. Final', 'Consumidor Final', subset=['categoria'])

# COMMAND ----------

# DBTITLE 1,DropDuplicates ( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.dropDuplicates(subset=List) -> DataFrame```

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Joins
# MAGIC - join() - ```DataFrame.join(DataFrame, Col(fk1 == pk2), Str) -> DataFrame```

# COMMAND ----------

# DBTITLE 1,Join( )
# MAGIC %md
# MAGIC ```
# MAGIC DataFrame.join(DataFrame, Col(fk1 == pk2), Str) -> DataFrame```

# COMMAND ----------

df_shop_carrito.join(df_shop_formapago, F.col('id_fpago') == df_shop_formapago.id, 'left')

# COMMAND ----------

# DBTITLE 1,Crear vistas temporales
for tabla in tablas:
    exec(f'{tabla.lower()} = df_{tabla.lower()}.createOrReplaceTempView("{tabla.lower()}")')

# COMMAND ----------

df_shop_clientes.createOrReplaceTempView('clientes')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT localidad, MAX(numero)
# MAGIC FROM clientes
# MAGIC GROUP BY localidad 
# MAGIC LIMIT 10

# COMMAND ----------

# DBTITLE 1,Py...SQL?
df_clientes2 = spark.sql('''
            SELECT localidad, MAX(numero)
            FROM clientes
            GROUP BY localidad 
            LIMIT 10
          ''')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Guardar DataFrame
# MAGIC - write.save() - ```DataFrame.write.save(path=Str, format=Str, mode=Str)```

# COMMAND ----------

# DBTITLE 1,Write.save( )
df_articulos.write.save(f'abfss://{container_origen}@{datalake}.dfs.core.windows.net/trusted-data/articulos', format='parquet', mode='overwrite')