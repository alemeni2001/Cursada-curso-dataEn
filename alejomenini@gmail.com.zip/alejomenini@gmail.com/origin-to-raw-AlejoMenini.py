# Databricks notebook source
# MAGIC %md
# MAGIC ## Analisis con PySpark.
# MAGIC
# MAGIC ### 1) subir los csv en databricks con una notebook "origin-to-raw" en una carpeta que diga "shop-carrito" seguido de una carpeta 'raw-data', ejemplo {contenedor}/shop-carrito/raw-data/shop_carrito.csv 
# MAGIC
# MAGIC ### 2) En un nuevo notebook "raw-to-trusted", realizar los joins correspondientes de las 7 tablas, la forma de unirlos es la siguiente:
# MAGIC
# MAGIC • Shop-carrito -> shop-clientes por el campo “id_cliente”
# MAGIC
# MAGIC • Shop-carrito -> shop_campanias por el campo “id_campania”
# MAGIC
# MAGIC • Shop-carrito -> shop_articulos por el campo “id_articulo_ppal”
# MAGIC
# MAGIC • Shop-carrito -> shop_formapago por el campo “id_fpago”
# MAGIC
# MAGIC • Shop-carrito -> shop_carrito_estados por el campo “estado”
# MAGIC
# MAGIC • Shop-carrito -> shop_carrito_estados_pago por el campo “estado_pago”
# MAGIC
# MAGIC Al finalizar guardar el tablon en formato parquet en una carpeta que diga Trusted, ejemplo {contenedor}/trusted/tablon_shop_carrito/
# MAGIC
# MAGIC ### 3) una vez que tengas el tablon shop_carrito, realizar los analisis correspondientes:
# MAGIC
# MAGIC a) Quiero saber qué cantidad de solicitudes de compra se encuentran en cada estado, y el porcentaje en relación al total.
# MAGIC
# MAGIC b) Quiero conocer los clientes principales de la empresa, generando un ranking por cantidad y otro por monto, teniendo en cuenta solamente las compras finalizadas (efectuadas).
# MAGIC
# MAGIC c) Queremos ver cuáles fueron los medios de pago más utilizados por los clientes
# MAGIC
# MAGIC d) Realizar un analisis donde me determine las campanias mas eficaces.
# MAGIC
# MAGIC e) realizar 2 analisis mas y que nos expliques los resultados obtenidos.

# COMMAND ----------

# MAGIC %md
# MAGIC # origin-to-raw

# COMMAND ----------

datalake = 'dlformacion'
contenedor_origen = 'shop-carrito'
contenedor_destino = 'alejo-menini'
tablas = ['articulos', 'campanias_gp', 'shop_carrito_estados_pago', 'shop_carrito_estados', 'Shop_carrito','Shop_clientes','shop_formapago']

# COMMAND ----------

#access_key = dbutils.secrets.get(scope = "dlformacion", key = "key1")
access_key = 'FIPeodgc8WLFK0TvcI+UHily5K2uvBp5AeryqRvqsc6fEapQj8vfEOhZs5R8xl9YX0MhvIaXK8L5+AStPinFvw=='
spark.conf.set(f'fs.azure.account.key.{datalake}.dfs.core.windows.net', access_key)

# COMMAND ----------

# MAGIC %md
# MAGIC Importamos los csv de nuestro datalake

# COMMAND ----------

for tabla in tablas:
    separador = ',' if (tabla in ['articulos', 'campanias_gp']) else ';'
    exec(f'''df_{tabla} = spark.read.load(
        f"abfss://{contenedor_origen}@{datalake}.dfs.core.windows.net/{tabla}.csv",
        format = "csv",
        sep = "{separador}",
        header = "true")''')

# COMMAND ----------

df_shop_formapago.display()

# COMMAND ----------

df_Shop_carrito.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Y los guardamos en nuestro contenedor, en formato csv en shopr-carrito/raw_data

# COMMAND ----------

for tabla in tablas:
    exec(f"""df_{tabla}.write.csv(
        path=f'abfss://{contenedor_destino}@{datalake}.dfs.core.windows.net/shop-carrito/raw_data/{tabla}.csv',
        header=True,
        mode = 'overwrite')""")

# COMMAND ----------

