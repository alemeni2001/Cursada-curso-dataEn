# Databricks notebook source
# MAGIC %md
# MAGIC ## Analisis con PySpark.
# MAGIC
# MAGIC ### 1) subir los csv en databricks con una notebook "origin-to-raw" en una carpeta que diga "shop-carrito" seguido de una carpeta 'raw-data', ejemplo {contenedor}/shop-carrito/raw-data/shop_carrito.csv 
# MAGIC
# MAGIC ### 2) En un nuevo notebook "raw-to-trusted", realizar los joins correspondientes de las 7 tablas, la forma de unirlos es la siguiente:
# MAGIC
# MAGIC • Shop-carrito -> shop-clientes por el campo “id_cliente”
# MAGIC
# MAGIC • Shop-carrito -> shop_campanias por el campo “id_campania”
# MAGIC
# MAGIC • Shop-carrito -> shop_articulos por el campo “id_articulo_ppal”
# MAGIC
# MAGIC • Shop-carrito -> shop_formapago por el campo “id_fpago”
# MAGIC
# MAGIC • Shop-carrito -> shop_carrito_estados por el campo “estado”
# MAGIC
# MAGIC • Shop-carrito -> shop_carrito_estados_pago por el campo “estado_pago”
# MAGIC
# MAGIC Al finalizar guardar el tablon en formato parquet en una carpeta que diga Trusted, ejemplo {contenedor}/trusted/tablon_shop_carrito/
# MAGIC
# MAGIC ### 3) una vez que tengas el tablon shop_carrito, realizar los analisis correspondientes:
# MAGIC
# MAGIC a) Quiero saber qué cantidad de solicitudes de compra se encuentran en cada estado, y el porcentaje en relación al total.
# MAGIC
# MAGIC b) Quiero conocer los clientes principales de la empresa, generando un ranking por cantidad y otro por monto, teniendo en cuenta solamente las compras finalizadas (efectuadas).
# MAGIC
# MAGIC c) Queremos ver cuáles fueron los medios de pago más utilizados por los clientes
# MAGIC
# MAGIC d) Realizar un analisis donde me determine las campanias mas eficaces.
# MAGIC
# MAGIC e) realizar 2 analisis mas y que nos expliques los resultados obtenidos.

# COMMAND ----------

# MAGIC %md
# MAGIC #Import

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
from pyspark.sql.types import *
from pyspark.sql.functions import col


# COMMAND ----------

# MAGIC %md
# MAGIC # raw-to-trusted

# COMMAND ----------

datalake = 'dlformacion'
contenedor_origen = 'alejo-menini'
contenedor_destino = 'alejo-menini'
tablas = ['articulos', 'campanias_gp', 'shop_carrito_estados_pago', 'shop_carrito_estados', 'Shop_carrito','Shop_clientes','shop_formapago']

# COMMAND ----------

spark = SparkSession.builder.appName('DataFrame').getOrCreate()

# COMMAND ----------

access_key = 'FIPeodgc8WLFK0TvcI+UHily5K2uvBp5AeryqRvqsc6fEapQj8vfEOhZs5R8xl9YX0MhvIaXK8L5+AStPinFvw=='
spark.conf.set(f'fs.azure.account.key.{datalake}.dfs.core.windows.net', access_key)

# COMMAND ----------

for tabla in tablas:
    exec(f'PATH_{tabla} = "abfss://{contenedor_origen}@{datalake}.dfs.core.windows.net/shop-carrito/raw_data/{tabla}.csv"')

# COMMAND ----------

# MAGIC %md
# MAGIC Importamos los csv de nuestro datalake

# COMMAND ----------

for tabla in tablas:
    # separador = ',' if (tabla in ['articulos', 'campanias_gp']) else ';'
    separador = ','
    exec(f"df_{tabla} = spark.read.load('abfss://{contenedor_origen}@{datalake}.dfs.core.windows.net/shop-carrito/raw_data/{tabla}.csv', format='csv', sep='{separador}', header='true', inferSchema = True)")

# COMMAND ----------

df_Shop_carrito.display()

# COMMAND ----------

df_campanias_gp.select('campania').display()

# COMMAND ----------

len(df_Shop_carrito.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC Mostramos los datos, aca se uso display, pero en las buenas practicas no seria conveniente usar display(si,agregar como en el ejemplo un limit) y mostrar todos los datos ya que podemos consumir recursos de nuestro procesador y aumentaria los costos 

# COMMAND ----------

df_shop_carrito_estados.limit(5).display()

# COMMAND ----------

df_Shop_clientes.limit(5).display()

# COMMAND ----------

len(df_Shop_carrito.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC Muestro algunos valores para comprobar que la carga se haya logrado de manera correcta usando display()

# COMMAND ----------

df_Shop_carrito.limit(5).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Por una cuestion de ambiguedad de los datos se tomo como desicion reemplazar los nombres de algunas columnas por el simple hecho que no den error a la hora de hacer nuestro left-join

# COMMAND ----------

df_shop_carrito_estados = df_shop_carrito_estados.withColumnRenamed("estado", "estado_df")

# COMMAND ----------

df_shop_carrito_estados.limit(5).display()

# COMMAND ----------

df_shop_carrito_estados_pago = df_shop_carrito_estados_pago.withColumnRenamed("estado", "estado_pago_df")

# COMMAND ----------

df_shop_carrito_estados_pago.limit(5).display()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC Cree una funcion la cual pasas por parametro dos dataset el cual se vana joinear segun un id2 que vendria a ser nuestra clave foranea y por otro lado previo al lef join verifica los nombres de las columnas y las renombra en caso de que esten repetidas segun el sting pasado por parametro, esto con el fin de que nuestros dataset no tengan problemas de ambiguedad

# COMMAND ----------

def limpiar_y_joinear(df1, df2, str, id2):

    df2 = df2.withColumnRenamed("id", "id_" + str)
    for columna in df2.columns:
        if columna in df1.columns and columna != 'id':
            df2 = df2.withColumnRenamed(columna, columna + '_' + str)

    return df1.join(df2, F.col(id2) == F.col("id_" + str), 'left')

# COMMAND ----------

df_Shop_carrito = limpiar_y_joinear(df_Shop_carrito, df_Shop_clientes, "cli", "id_cliente")
df_Shop_carrito = limpiar_y_joinear(df_Shop_carrito, df_campanias_gp, "cam","id_campania")
df_Shop_carrito = limpiar_y_joinear(df_Shop_carrito, df_articulos, "art", "id_articulo_ppal")
df_Shop_carrito = limpiar_y_joinear(df_Shop_carrito, df_shop_formapago,"fpag", "id_fpago")
df_Shop_carrito = limpiar_y_joinear(df_Shop_carrito, df_shop_carrito_estados, "est", "estado_df")
df_Shop_carrito = limpiar_y_joinear(df_Shop_carrito, df_shop_carrito_estados_pago, "estp", "estado_pago_df")

# COMMAND ----------

len(df_Shop_carrito.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC #SAVE Dataframe

# COMMAND ----------

df_Shop_carrito.write.save(f'abfss://{contenedor_destino}@{datalake}.dfs.core.windows.net/shop-carrito/trusted-data/tablon-shop-carrito', format='parquet', mode='overwrite')